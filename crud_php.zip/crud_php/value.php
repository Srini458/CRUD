<?php
//include connection.php
include 'connection.php';


if(isset($_POST['submit'])){
	
	//form variable
	$name = $_POST['name'];
	$age = $_POST['age'];
	$email = $_POST['email'];
	
	//if empty it display "Failed"
	if(empty($name) || empty($age) || empty($email)){
		
		echo "Failed" ;
		
	}else{
	
	//Insert Query to Mysql database 'database name is crud'
	$query = mysqli_query($conn,"INSERT INTO userlist (name,age,email) VALUES ('$name','$age','$email')");
	
	//if variable values inserted into database it display success and get back to index.php
	echo "Success" ;
	
	header("Location: index.php");
	}
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>