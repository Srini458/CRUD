<?php
//include connection.php
include 'connection.php';

if(isset($_POST['update'])){
	
	//set editable value to the text field
	$id = mysqli_real_escape_string($conn,$_POST['id']);
	$name = mysqli_real_escape_string($conn,$_POST['name']);
	$age = mysqli_real_escape_string($conn,$_POST['age']);
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	
	//if empty it display "Failed"
	if(empty($name) || empty($age) || empty($email)){
		
		echo "Failed" ;
		
	}else{
	
	//if values showed in text field it will update
	$result = mysqli_query($conn,"UPDATE userlist SET name='$name', age='$age', email='$email' WHERE id=$id");
	
	//if values updated get back to index.php
	echo "Success" ;
	
	header("Location: index.php");
	}
}
?>
<?php

//get id from fetched row
$id = $_GET['id'];

//select that id 
$result = mysqli_query($conn,"SELECT * FROM userlist WHERE id=$id");

//fetch id values
while($res = mysqli_fetch_array($result)){
	$name = $res['name'];
	$age = $res['age'];
	$email = $res['email'];
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<div>
<p><a href="index.php">home</a></p>

<form action="edit.php" method="post">
<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
<table width="200">
  <tbody>
    <tr>
      <td>Name</td>
      <td><input type="text" name="name" value="<?php echo $name; ?>"></td>
    </tr>
    <tr>
      <td>Age</td>
      <td><input type="number" name="age" value="<?php echo $age; ?>"></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><input type="email" name="email" value="<?php echo $email; ?>"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="submit" name="update" value="Update"></td>
    </tr>
  </tbody>
</table>
</form>

</div>
</body>
</html>