<?php
//include connection.php
include 'connection.php';

//get id from fetched row
$id = $_GET['id'];

//delete that id from row
$result = mysqli_query($conn,"DELETE FROM userlist WHERE id=$id");

//get back to index.php
header("Location:index.php");

?>