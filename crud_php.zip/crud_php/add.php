<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="value.php" method="post">
	<table width="200">
  <tbody>
    <tr>
      <td>Name</td>
      <td><input type="text" name="name" required></td>
    </tr>
    <tr>
      <td>Age</td>
      <td><input type="number" name="age" required></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><input type="email" name="email" required></td>
    </tr>
    <tr>
      <td colspan="2"><input type="submit" name="submit" value="Add"></td>
    </tr>
  </tbody>
</table>

</form>
</body>
</html>