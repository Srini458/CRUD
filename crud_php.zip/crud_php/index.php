<?php
//include connection.php
include 'connection.php';

//Select Query from Mysql database to display record
$result = mysqli_query($conn,"SELECT * FROM userlist");
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
table,tr,th,td{
	border-collapse:collapse;
	border:1px solid #000;
	padding:5px;
}
</style>
</head>

<body>
<div>
<p><a href="add.php">Add New Database</a></p>

<table>
	<tr>
    	<th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Email</th>
        <th colspan="2">Update</th>
    </tr>
    <?php 
		//fetch database value to display
		while($row = mysqli_fetch_array($result)){
	?>
    <tr>
    	<td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['age']; ?></td>
        <td><?php echo $row['email']; ?></td>
       	
        <td><a href="edit.php?id=<?php echo $row['id']; ?>"><button type="button">Edit</button></a></td>
        <td><a href="delete.php?id=<?php echo $row['id']; ?>"><button type="button">Delete</button></a></td>
    </tr>
    <?php
		}
	?>
</table>

</div>
</body>
</html>